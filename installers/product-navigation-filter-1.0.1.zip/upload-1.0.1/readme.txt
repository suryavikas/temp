This is a vqmod, it does not overwrite any tpl files :)


A) Pre requisite, you must have vqmod installed and working, using the default theme. Tested only on Opencart 1.5.2.1.

B) File have been zipped with appropriate directory structure

C) To make the required changes to the UI, use filters.css


Note: I have tested this module on IE 8, FF 12 and Chrome 18.0.

Pls report any bugs or feature suggestions you think could help make this module better.